<template>
<v-container>
    <!-- 기본 크기 슬라이더 -->
    <div class="mb-4" style="position: relative; z-index: 2">
      <v-slider
        :model-value="size"
        @update:model-value="updateSize"
        :min="1"
        :max="99"
        :step="1"
        :disabled="advancedEnabled"
        hide-details
        class="align-center"
      >
        <template #append>
          <v-text-field
            :model-value="size"
            @update:model-value="updateSize"
            :disabled="advancedEnabled"
            density="compact"
            type="number"
            hide-details
            single-line
            class="scale-input ml-2"
          />
        </template>
      </v-slider>
    </div>

    <!-- 고급 설정 체크박스 -->
    <v-checkbox
      v-model="advancedEnabled"
      label="고급 크기 설정 (X/Y/Z)"
      hide-details
      class="mb-2"
    />

    <!-- 고급 크기 슬라이더 (X/Y/Z) -->
    <div v-if="advancedEnabled">
      <div
        v-for="axis in ['X', 'Y', 'Z']"
        :key="axis"
        class="d-flex align-center mb-3"
      >
        <span class="axis-label text-body-2 mr-2">{{ axis }}</span>
        <v-slider
          v-model="layer[`scale${axis}`]"
          :min="1"
          :max="99"
          :step="1"
          hide-details
          class="custom-slider flex-grow-1 mx-2"
        />
        <v-text-field
          v-model="layer[`scale${axis}`]"
          type="number"
          density="compact"
          hide-details
          single-line
          class="scale-input ml-2"
        />
      </div>
    </div>
</v-container>
</template>

<script setup>
const props = defineProps({
  size: Number,
  layer: Object,
})
const emit = defineEmits(['update:size'])

const advancedEnabled = ref(false)

function updateSize(val) {
  emit('update:size', val)
}
</script>

<style scoped>
::v-deep(.v-slider) {
  margin: 0 !important;
}
.custom-slider {
  height: 14px !important;
  --v-slider-track-size: 2px;
}
.scale-input {
  width: 66px;
  min-width: 66px;
  max-width: 66px;
}
.axis-label {
  font-size: 14px;
  font-weight: 500;
  width: 20px;
  display: inline-block;
  text-align: left;
}
</style>