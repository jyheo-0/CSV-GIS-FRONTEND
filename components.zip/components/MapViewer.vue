<template>
  <iframe
      src="http://192.168.1.108/Statistics/"
      frameborder="0"
      class="map-frame"
  />
</template>

<style scoped>
.map-frame {
  width: 100%;
  height: 100%;
  border: none;
  display: block;
}
</style>