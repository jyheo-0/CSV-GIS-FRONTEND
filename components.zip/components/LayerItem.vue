<template>
  <v-expansion-panels variant="accordion" class="mb-2">
    <v-expansion-panel elevation="1" class="top-layer-panel">
      <v-expansion-panel-title class="custom-title">
        <v-icon
          class="mr-2"
          style="cursor: pointer"
          @click.stop="layer.visible = !layer.visible"
          :icon="layer.visible ? 'mdi-eye' : 'mdi-eye-off'"
          :color="layer.visible ? 'light-grey' : 'grey'"
        />
        {{ layer.name }}
      </v-expansion-panel-title>

      <v-expansion-panel-text class="nested-panel">
        <v-expansion-panels variant="accordion" multiple>
          <v-expansion-panel>
            <v-expansion-panel-title>
              마커 타입
              <span class="preview">{{ markerType }}</span>
            </v-expansion-panel-title>
            
            <v-expansion-panel-text>
              <MarkerTypeSelector :value="layer.type" @update="onUpdateType" />
            </v-expansion-panel-text>
          </v-expansion-panel>

          <v-expansion-panel>
            <v-expansion-panel-title>마커 색상</v-expansion-panel-title>
            <v-expansion-panel-text>
              <MarkerColorPicker
                v-model:color="layer.baseColor"
                :preset-colors="presetColors"
              />
            </v-expansion-panel-text>
          </v-expansion-panel>

          <v-expansion-panel>
            <v-expansion-panel-title>마커 크기</v-expansion-panel-title>
            <v-expansion-panel-text>
              <MarkerSizeControl v-model:size="layer.size" :layer="layer" />
            </v-expansion-panel-text>
          </v-expansion-panel>

          <v-expansion-panel>
            <v-expansion-panel-title>라벨 설정</v-expansion-panel-title>
            <v-expansion-panel-text>
              <MarkerLabelSettings
                v-model:label-field="labelField"
                v-model:label-position="labelPosition"
                v-model:label-size="labelSize"
                v-model:label-visible="labelAlwaysVisible"
                v-model:label-color="labelColor"
                :csv-headers="csvHeaders"
              />
            </v-expansion-panel-text>
          </v-expansion-panel>
        </v-expansion-panels>
      </v-expansion-panel-text>
    </v-expansion-panel>
  </v-expansion-panels>
</template>

<script setup>
import MarkerTypeSelector from './MarkerTypeSelector.vue'
import MarkerColorPicker from './MarkerColorPicker.vue'
import MarkerSizeControl from './MarkerSizeControl.vue'
import MarkerLabelSettings from './MarkerLabelSettings.vue'
import { ref } from 'vue'

const props = defineProps({
  layer: Object
})
const emit = defineEmits(['update'])

const csvHeaders = ['이름', '주소', '설치년도', '관리번호']
const presetColors = [
  '#ff6b6b', '#ffa94d', '#ffd43b', '#38b000',
  '#3bc9db', '#4c6ef5', '#845ef7', '#ffffff', '#111111'
]

const labelField = ref('이름')
const labelPosition = ref('top')
const labelSize = ref(14)
const labelAlwaysVisible = ref(true)
const labelColor = ref('#333333')

function onUpdateType(type) {
  emit('update', { id: props.layer.id, type })
}
</script>

<style scoped>
.custom-title {
  background-color: #2c2c2c;
  font-weight: bold;
  border-radius: 6px 6px 0 0;
}

.nested-panel {
  background-color: #1f1f1f;
  padding: 0;
  border-radius: 0 0 6px 6px;
}

::v-deep(.v-expansion-panel-text__wrapper) {
  padding: 0 !important;
}

/* 상위 패널만 열렸을 때 타이틀 배경 진하게 */
::v-deep(.top-layer-panel.v-expansion-panel--active > .v-expansion-panel-title) {
  background-color: #292929;
  transition: all 0.2s ease;
}

/* 하위 패널은 열려도 배경색 변경 없음 */
::v-deep(.nested-panel .v-expansion-panel--active > .v-expansion-panel-title) {
  background-color: #1f1f1f; /* 원래 배경색 유지 */
}

/* 하위 패널 파란줄 효과는 유지 */
::v-deep(.nested-panel .v-expansion-panel--active) {
  position: relative;
  background-color: #1f1f1f;
  z-index: 0; /* 혹시 모르니까 명시 */
}



</style>
