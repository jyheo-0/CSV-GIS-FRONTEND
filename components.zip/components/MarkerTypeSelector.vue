<template>
  <div>
    <v-card width="100%">
      <v-container>
        <v-row dense>
          <v-col v-for="(item, index) in options" :key="index" cols="4">
            <v-card
              class="icon-thumb"
              :class="{ selected: selected.value === item.value }"
              @click="selectShape(item)"
            >
              <img :src="`/makers/${item.value}.svg`" alt="icon" width="30" height="30" />
              <div class="label">{{ item.label }}</div>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </v-card>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({ value: String })
const emit = defineEmits(['update'])

const options = [
  { value: 'none', label: '선택 안함' },
  { value: 'point', label: '점' },
  { value: 'circle', label: '원' },
  { value: 'vertical-line', label: '수직선' },
  { value: 'cylinder', label: '실린더' },
  { value: 'sphere', label: '구' },
  { value: 'cone', label: '콘' },
  { value: 'symbol', label: '심볼' },
  { value: 'icon', label: '아이콘' }
]

const selected = ref(options.find(opt => opt.value === props.value) || options[0])

watch(() => props.value, val => {
  selected.value = options.find(opt => opt.value === val) || options[0]
})

function selectShape(item) {
  selected.value = item
  emit('update', item.value)
}
</script>

<style scoped>
.icon-thumb {
  width: 100%;
  height: 70px;
  background-color: #1e1e1e;
  color: white;
  border: 1px solid #444;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
}
.icon-thumb.selected {
  border: 2px solid #2196f3;
  background-color: #263238;
}
.icon-thumb .label {
  margin-top: 2px;
  font-size: 12px;
  color: #ccc;
}
</style>
