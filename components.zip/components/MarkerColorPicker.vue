<template>
<v-container>
    <div class="d-flex align-center flex-wrap gap-2 mb-2">
      <div
        v-for="color in presetColors"
        :key="color"
        :style="{ backgroundColor: color }"
        class="color-circle"
        :class="{ selected: color === localColor }"
        @click="updateColor(color)"
      />
    </div>
    <v-color-picker
      v-model="localColor"
      flat
      hide-inputs
      hide-canvas
      class="rounded border custom-color-picker"
    />
</v-container>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  color: String,
  presetColors: Array
})
const emit = defineEmits(['update:color'])
const localColor = ref(props.color)

watch(() => props.color, val => localColor.value = val)
watch(localColor, val => emit('update:color', val))

function updateColor(color) {
  localColor.value = color
}
</script>

<style scoped>
.color-circle {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  cursor: pointer;
  transition: transform 0.2s;
  margin-left: 7px;
}
.color-circle:hover {
  transform: scale(1.1);
}
.color-circle.selected {
  border: 2px solid;
}
.custom-color-picker {
  width: 280px;
  padding: 0;
  min-width: unset;
  max-width: 100%;
}
::v-deep(.v-color-picker__controls) {
  padding: 0px 8px !important;
  gap: 4px !important;
}
</style>